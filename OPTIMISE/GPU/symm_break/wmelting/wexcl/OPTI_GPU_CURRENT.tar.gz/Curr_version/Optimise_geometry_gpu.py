#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 31 12:04:54 2024

@author: yqb22156
"""

from oxdna_to_internal_wflip import read_oxdna_trajectory_standard_order
import parameters_list as parl
import torch
import functions as fun
import cost_function as cfun
import config as cg
import sys
import time
from scipy import optimize

# READ CONFIG FILE
if len(sys.argv) != 2 :
    print("Unknown argument format.")
    print("Usage: python3 optimise.py config_file")
    sys.exit()

start_time = time.time()

config_file = sys.argv[1]

PARS_LIST = parl.PARS_LIST
par_index = parl.par_index


#X = torch.tensor([0,1,2])
#print(X.device)


###################################################################################################
############## INITIALISE PARAMETERS FROM model.h E SD PARAMETERS FILE ############################
###################################################################################################

#print(stck_fact_eps)
model_file = open("model.h",'r')
pars_from_modelh, vals_from_modelh = fun.read_vanilla_parameters(model_file)    
model_file.close()

SD_par_file = open("oxDNA_sequence_dependent_parameters_in.txt",'r')   
over_indices, over_vals, stck_fact_eps_read, stck_fact_eps = fun.read_pars_from_SD_file(SD_par_file)    
SD_par_file.close()

if stck_fact_eps_read :
    print("STCK_FACT_EPS read from SD parameters file")
else:
    print("WARNING: No STCK_FACT_EPS found in SD parameters file")

OXPS_zero, shifts = fun.init_oxpars(pars_from_modelh, vals_from_modelh, over_indices, over_vals, cg.T, stck_fact_eps)

###################################################################################################
############## READ OPTIM OPTIONS  ################################################################
###################################################################################################

#READ PARAMETERS
if fun.read_config(config_file) == False :
    sys.exit()

test_file = open("opti_p_test.txt",'w')
for l in range(len(cfun.OPT_PAR_LIST)) :
    print(cfun.OPT_PAR_LIST[l],file=test_file)

test_file.close()

test_file = open("opti_p_test1.txt",'w')
print(OXPS_zero[45],file = test_file)
print(OXPS_zero[1],file = test_file)

print(OXPS_zero[34],file = test_file)
test_file.close()


#########################################################################################################################
############## READ TRAJECTORY, COMPUTE OXDNA COORDINATES (i.e angles and distances) AND INTERNAL COORDINATES ###########
#########################################################################################################################


fene_r = []
stck_r = []
th4_bn = []
th5 = []
th6 = []
cosphi1 = []
cosphi2 = []
types_bn = []
hydr_r = []
th1 = []
th2 = []
th3 = []
th4_unbn = []
th7 = []
th8 = []
types_unbn = []

rclow, rchigh = fun.find_cuts_for_lists(OXPS_zero)
print("cuts: "+str(rclow)+" "+str(rchigh))

for l in range(cg.Nseq):
    for m in range(cg.Nreps) :
        tr_file = open("Seq"+str(l)+"/Rep"+str(m)+"/trajectory.dat",'r')
        topo_file = open("Seq"+str(l)+"/Rep"+str(m)+"/generated.top", 'r')


        #oxdna distances, types and angles
        fr, sr, t4bn, t5, t6, cp1, cp2, tbn, hr, t1, t2, t3, t4un, t7, t8, tun = fun.read_oxdna_trajectory_dist_and_angles(rclow, rchigh, tr_file, topo_file)

        if m == 0:
            fene_r.append(fr)
            stck_r.append(sr)
            th4_bn.append(t4bn)
            th5.append(t5)
            th6.append(t6)
            cosphi1.append(cp1)
            cosphi2.append(cp2)
            types_bn.append(tbn)
            hydr_r.append(hr)
            th1.append(t1)
            th2.append(t2)
            th3.append(t3)
            th4_unbn.append(t4un)
            th7.append(t7)
            th8.append(t8)
            types_unbn.append(tun)
        else:
            fene_r[l].extend(fr)
            stck_r[l].extend(sr)
            th4_bn[l].extend(t4bn)
            th5[l].extend(t5)
            th6[l].extend(t6)
            cosphi1[l].extend(cp1)
            cosphi2[l].extend(cp2)
            types_bn[l].extend(tbn)
            hydr_r[l].extend(hr)
            th1[l].extend(t1)
            th2[l].extend(t2)
            th3[l].extend(t3)
            th4_unbn[l].extend(t4un)
            th7[l].extend(t7)
            th8[l].extend(t8)
            types_unbn[l].extend(tun)

        tr_file.close()
        topo_file.close()

        tr_file = open("Seq"+str(l)+"/Rep"+str(m)+"/trajectory.dat",'r')
        topo_file = open("Seq"+str(l)+"/Rep"+str(m)+"/generated.top", 'r')

        #internal coordinates
        traj = read_oxdna_trajectory_standard_order(tr_file, topo_file)

        if l == 0 :
            fun.store_internal_coord(traj,l,cg.ids,cg.in_j[l],cg.fin_j[l],cg.in_snap,True)
        else  :
            fun.store_internal_coord(traj,l,cg.ids,cg.in_j[l],cg.fin_j[l],cg.in_snap,False)

        tr_file.close()
        topo_file.close()


#make unbnd tensor square. Extra unbnd pairs have zero interaction energy.

max_ints = 0
for l in range(cg.Nseq) :
    for j in range(len(types_unbn[l])):
        if len(types_unbn[l][j]) > max_ints:
           max_ints = len(types_unbn[l][j])
print("max unbn pairs: "+str(max_ints))
for l in range(cg.Nseq) :
    for j in range(len(types_unbn[l])):
        for z in range(len(types_unbn[l][j]), max_ints):
            types_unbn[l][j].append(0)
            hydr_r[l][j].append(0.)

            th1[l][j].append(0.)
            th2[l][j].append(0.)
            th3[l][j].append(0.)

            th4_unbn[l][j].append(0.)
            th7[l][j].append(0.)
            th8[l][j].append(0.)


print("Check lengths:")
print("fene_r: "+str(len(fene_r))+", "+str(len(fene_r[0]))+", "+ str(len(fene_r[0][0])))
print("hydr_r: "+str(len(hydr_r))+", "+str(len(hydr_r[0]))+", "+ str(len(hydr_r[0][0])))
print("int_coord: "+str(len(cfun.internal_coords))+", "+str(len(cfun.internal_coords[0]))+", "+ str(len(cfun.internal_coords[0][0])))

###################################################################################################
############## SETUP TENSORS FOR COST FUNCTION ####################################################
###################################################################################################




#create all tensors on the gpu. Change this to easily swap between gpu and cpu
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")



cfun.init_tensors(device,fene_r, stck_r, th4_bn, th5, th6, cosphi1, cosphi2, types_bn, hydr_r, th1, th2, th3,\
                  th4_unbn, th7, th8, types_unbn, shifts, OXPS_zero)

#build tensors imposing continuity
cfun.build_continuity_tensors()

print("Continuity tensors cool.")

#build masks (for selecting optim parameters and marginalising mu and cov) and symm tensors (for imposing symmetries)
cfun.build_masks_and_symm_tensors()

print("Masks cool")


#create reduced targets and compute cov^{-1}
cfun.reduce_targets()

print("Targets reduced")

#compute initial energy and modulation factors
cfun.compute_initial_energy()

print("Computed initial energy")

tfile = open("fene_in.txt", 'w')

EN = cfun.EN_FENE_IN.sum(dim=2)/48

for i in range(cg.Nseq) :
   for j in range(len(EN[i])):
      if (j+1)%10 == 0:
          print(str(float(EN[i][j])),file=tfile)
   print("\n",file=tfile)

tfile.close()


tfile = open("stck_in.txt", 'w')

EN = cfun.EN_STCK_IN.sum(dim=2)/48

for i in range(cg.Nseq) :
   for j in range(len(EN[i])):
      if (j+1)%10 == 0: print(str(float(EN[i][j])),file=tfile)
   print("\n",file=tfile)

tfile.close()


tfile = open("hydr_in.txt", 'w')

EN = cfun.EN_HYDR_IN.sum(dim=2)/48

for i in range(cg.Nseq) :
   for j in range(len(EN[i])):
      if (j+1)%10 == 0: print(str(float(EN[i][j])),file=tfile)
   print("\n",file=tfile)

tfile.close()



tfile = open("crst_in.txt", 'w')

EN = (cfun.EN_CRST_33_IN+cfun.EN_CRST_55_IN).sum(dim=2)/48

for i in range(cg.Nseq) :
   for j in range(len(EN[i])):
      if (j+1)%10 == 0: print(str(float(EN[i][j])),file=tfile)
   print("\n",file=tfile)

tfile.close()


#read initial optim parameters values


ids = []
for i in range(len(cfun.OPT_PAR_LIST)) :
    id = cfun.OPT_PAR_LIST[i][0]
    ty = cfun.OPT_PAR_LIST[i][1]
    ids.append(id*256+ty)


IDS_OP = torch.tensor(ids,device=device)
OPTI_PAR = torch.gather(torch.reshape(cfun.CURR_PARS,(-1,)),0,IDS_OP)

"""

print(IDS_OP[0])
print(cfun.OPT_PAR_LIST[0][0],cfun.OPT_PAR_LIST[0][1])

print(IDS_OP[10])
print(cfun.OPT_PAR_LIST[10][0],cfun.OPT_PAR_LIST[10][1])

OPTI_PAR[0] = 0.5
OPTI_PAR[10] = 0.3

print(OPTI_PAR[0])
print(OPTI_PAR[10])


"""

#for i in range(16):
#    OPTI_PAR[i] += 0.02

"""

timefile = open("runtime.txt",'w')
print("Run time [s]: " + str(time.time() - start_time),file=timefile)
timefile.close()

"""

time_cfun = time.time()

torch.autograd.set_detect_anomaly(True)


OPTI_PAR.requires_grad_()
optimizer = torch.optim.Adam([OPTI_PAR], lr = 0.01)


list_params = []

print("OPTIMISING")

cfun.PAR0 = torch.clone(cfun.CURR_PARS)

TMP = torch.tensor(OPTI_PAR,device='cpu')

X0 = TMP.numpy()

low_bond = torch.tensor(TMP, device='cpu').numpy()
up_bond = torch.tensor(TMP, device='cpu').numpy()

for n in range(len(low_bond)) :
    if cfun.OPT_PAR_LIST[n][0] == 1:
        low_bond[n] = low_bond[n]*0.97
        up_bond[n] = up_bond[n]*1.03
    elif cfun.OPT_PAR_LIST[n][0] == 2:
        low_bond[n] = low_bond[n]*0.95
        up_bond[n] = up_bond[n]*1.05
    elif cfun.OPT_PAR_LIST[n][0] == 45:
        low_bond[n] = low_bond[n]*0.95
        up_bond[n] = up_bond[n]*1.05
    elif cfun.OPT_PAR_LIST[n][0] == 101 or cfun.OPT_PAR_LIST[n][0] == 140:
        low_bond[n] = 2.96709
        up_bond[n] = 3.31609
    else:
        low_bond[n] = low_bond[n]*0.5
        up_bond[n] = up_bond[n]*2.

bnd = optimize.Bounds(low_bond,up_bond)


print("S0: "+str(cfun.COST(X0)))


def Callback(sol):
    print("x: ")
    tmp = []
    for i in range(len(sol)):
        tmp.append(sol[i]/X0[i])
    print(tmp)
    print("S: "+str(cfun.COST(sol)))

sol = optimize.minimize(cfun.COST,X0, method='L-BFGS-B', callback=Callback, bounds=bnd, options={'maxfun':100000,'iprint': 1})
#sol = optimize.minimize(cfun.COST,X0, method='L-BFGS-B', bounds=bnd, options={'maxfun':100000,'iprint': 1})

S = cfun.COST(sol.x)
print(S)



"""

for n in range(50):


    optimizer.zero_grad()

    loss = cfun.COST(OPTI_PAR)
    print(loss)
    loss.backward()
    optimizer.step()
    list_params.append(OPTI_PAR.detach().clone())



size = len(list_params)


print(size)
print("Pars_fin:")
print(list_params[0])
print(list_params[size-1]/list_params[0])


#print("Pars_fin/Pars_in: ")
#print(list_params[size-1]/list_params[0])
#for n in range(10000) :
#    cfun.COST(OPTI_PAR)


"""

#print("10k cfun time: " + str(time.time()-time_cfun))

print("Everything cool.")
